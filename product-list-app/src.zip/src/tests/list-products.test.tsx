import {render, screen, waitFor} from '@testing-library/react';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import ListProducts from '../components/ListProducts';
import { store } from '../redux/store';
import axios from 'axios';
import { Product } from '../model/Product';

jest.mock("axios");
test("ListProducts", () => {
    (axios.get as jest.Mock).mockResolvedValue({data: [new Product(1, "p1", 1000, ""), new Product(2, "p1", 2000, "") ]});
    render(<Provider store = {store}><BrowserRouter><ListProducts/></BrowserRouter></Provider>) //to make use of use navigate we wrap around router
  
    waitFor(() => {
        expect(screen.getByText("List Products")).toBeTruthy();
        let allProducts = screen.getAllByTestId("product");
        expect(allProducts.length).toBe(2);
    })

})

//trying to test usecase of useSelector -> to get the inputs from the store so wrap it around provider as redux in our application is called from provider store
//if u are trying to test usecase of context -> wrap areound AppThemeProvider