//Higher Order Component
//hoc is always a function that receives the component that it needs to wrap
//hoc will return a new React Component which can be a function or class component
export const withBorder = (Component: any) => {


    return function BorderHOC(props: any) {
        return(
            <div style={{border: '2px solid red', padding: '5px', margin: '5px'}}>
                <Component {...props}/>
            </div>
        )
    }

}
