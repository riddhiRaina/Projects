import {combineReducers, createStore, applyMiddleware, compose} from 'redux';
import{authReducer} from './authReducer';
import {gadgetsReducer} from './gadgetsReducer';
import thunk from 'redux-thunk';
import { configureStore } from '@reduxjs/toolkit';

//integrate both reducers
const reducers = combineReducers({
    auth: authReducer,
    gadgets: gadgetsReducer
})
//In large apps, reducer can become lengthy functions, so create multiple reducers and combine it in one file.

//MiddleWare
const loggingMiddleware = () => {
    return (next: any) => { //next is handle for next middleware in chain
        return (action: any) => {
            console.log("[loggingMiddleware action b/4]", action);
            console.log("[loggingMiddleware state b/4]", store.getState());
            const result = next(action);
            console.log("[loggingMiddleware action b/4]", action);
            console.log("[loggingMiddleware state b/4]", store.getState());
        }

    }
}

//MiddleWare for Async API Call using redux thunk lib and then dispatch the action


//export const store = createStore(reducers, (window as any) .__REDUX_DEVTOOLS_EXTENSION__ && (window as any) .__REDUX_DEVTOOLS_EXTENSION__());
//export const store = createStore(reducers, applyMiddleware(loggingMiddleware));

//For redux in dev tools - advance set up -> import compose
//using store with middlewarae and the redux dev tools extension
//const composeEnhancers = (window as any).__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
//export const store = createStore(reducers, /* preloadedState, */ composeEnhancers(applyMiddleware(loggingMiddleware, thunk)));

//**Configure Store */
export const store = configureStore({
    reducer: reducers,
    middleware: [loggingMiddleware, thunk],
    devTools: true
});
export type AppDispatch = typeof store.dispatch;
export type AppState = ReturnType<typeof store.getState>;
//used redux to create store and reducer. 
//store should be available to all components. The dispatch and re rendering of the components should happen
//whatever we have created in redux, we need to integrate to our react application. -> Library to use is redux React