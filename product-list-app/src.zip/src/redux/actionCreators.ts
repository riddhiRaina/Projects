import axios from "axios";
import { CartIem } from "../model/CartItem";
import { Product } from "../model/Product";
import { GadgetsAction } from "./gadgetsReducer";
import { AppDispatch } from "./store";

export function createAddToCartAction(payload: CartIem): GadgetsAction{

    return {
        type: "ADD_TO_CART",
        payload
    }
}

export function createRemoveToCartAction(product: Product): GadgetsAction{

    return {
        type: "REMOVE_FROM__CART",
        product
    }
}

export function createSetProductsAction(){
    return async (dispatch: AppDispatch) => { //return function which gives handle to dispatch
        try{
            const url = process.env.REACT_APP_BASE_URL + "/products";
            const response = await axios.get<Product[]>(url);
            const products = response.data;

            dispatch({
                type: "SET_PRODUCTS", 
                products: products
            });
        } catch (error) {

        }
    }
}