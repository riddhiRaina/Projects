import { createAsyncThunk, createSlice, PayloadAction } from '@reduxjs/toolkit';
import axios from 'axios';
import { CartIem } from '../model/CartItem';
import {Product} from '../model/Product';
//Defining structure
export interface GadgetState{
    // cart: any[],
    cart: CartIem[],
    products: Product[],
}

const initState: GadgetState = {
    cart: [],
    products: [],
}

export interface GadgetsAction{
    type:string;
    payload?: CartIem; //add to cart pass payload
    product?: Product; //remove from cart pass product
    products?: Product[]
}


// export const gadgetsReducer = (currentState = initState, action: GadgetsAction) => {
    
//     // {type: "ADD_TO_CART", payload: {product:{}, quantity:1}}
//     if(action.type === "ADD_TO_CART"){

//         const cart = [...currentState.cart];
//         if(action.payload){
//             cart.push(action.payload);
//         }
//         return{
//             ...currentState,
//             cart: cart
//         }
//     }

//     // {type: "REMOVE_FROM_CART", product: {}}
//     if(action.type === "REMOVE_FROM_CART"){
//         const cart = [...currentState.cart];
//         const index = cart.findIndex(item => item.product?.id === action.product?.id)
//         if(index != -1){
//             cart.splice(index,1);
//         }
//         return{
//             ...currentState,
//             cart:cart
//         }
//     }

//     // {type: "SET_PRODUCTS", products:[]]}
//     if(action.type === "SET_PRODUCTS"){

//         if(action.products){
//             return {
//                 ...currentState,
//                 products: action.products
//             }
//         }
        
//     }
//     return currentState;
// }


//re-write gagetRedure using redux toolkit -> use createSlice -> we can work with state with immutable fashion
export const fetchProductAsync = createAsyncThunk("fetchProductsAsync", async () => {
    try{
        const url = process.env.REACT_APP_BASE_URL + "/products";
        const response = await axios.get<Product[]>(url);
        const products = response.data;
        return products;

    } catch (error) {

    }
});

const gagetSlice = createSlice({
    initialState: initState,
    name: "gadgetSlice",
    reducers: {

        addItemToCart: (currentState, action: PayloadAction<CartIem>) => {
            currentState.cart.push(action.payload);
        }, //no need to worry about immutability - its taken care of library

        removeFromCart: (currentState, action: PayloadAction<Product>) => {
            const index = currentState.cart.findIndex(item => item.product?.id === action.payload.id);
            if(index !== -1){
                currentState.cart.splice(index, 1);
            }
        },

    },

    extraReducers: (builder) => {
        builder.addCase(fetchProductAsync.fulfilled, (currentState, action) => {
            if(action.payload){
                currentState.products = action.payload;
            }

        })
    }
});

//We need reducer
export const gadgetsReducer = gagetSlice.reducer;
export const {addItemToCart, removeFromCart} = gagetSlice.actions;