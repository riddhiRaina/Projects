import { Product } from "./Product";

export class CartIem{
    constructor(public product?: Product, public quantity?: number){}
}