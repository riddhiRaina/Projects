export class Product{

    // id: number;
    // name: string;
    // price: number;
    // description: string;
    // imageUrl : string

    constructor(public id?: number, public name?: string, public price?: number, public description?: string, 
                                                                                  public imageUrl?: string){
          

    }
    

}

// var p = new Product(1, "name", 1000, "desc", "image");
// p = new Product();