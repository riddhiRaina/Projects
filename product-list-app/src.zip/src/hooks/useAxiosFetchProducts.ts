// we can use libraries to fetch as well, but we doing it from axios
import axios from 'axios';
import {useState, useEffect} from 'react';
import { Product } from '../model/Product';

export function useAxiosFetchProducts() {

    const [products, setProducts] = useState<Product[]>([]);
    useEffect(() => {
        //invoked as soon as component is mounted
        fetchProducts(); // callback which is registered
    }, []) // if we give dependencies [], invoking will happen only during the dependencies


    async function fetchProducts(){
        try{

            const url =process.env.REACT_APP_BASE_URL + "/products" ; //hardcoding url - not good thing to do. Put it in client side config file
            const response = await axios.get<Product[]>(url);
            setProducts(response.data);

        } catch (error){
            console.log("useAxiosFetchProducts", error);
        }
    }

    return [products, setProducts] as const;

}

