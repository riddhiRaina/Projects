// import React from 'react';
// import logo from './logo.svg';
// import './App.css';
// //import {BrowserRouter as Router, Routes, }

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.tsx</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

// export default App;

// import React from 'react';
// import logo from './logo.svg';
// import Hello from './components/Hello';
// import './App.css';
// import Counter from './components/Counter';
// import FnCounter from './components/FnCounter';

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.tsx</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>

//       <main>
//         {/* <Hello message="React"/>
//         <Hello message="World"/> */}

//         {/* <Counter value={10} title='Count' />
//         <Counter value={15}/> */}

//         <FnCounter/>
        
//       </main>
//     </div>
//   );
// }

// export default App;

// import React from 'react';
// import Hello from './components/Hello';
// import Counter from './components/Counter';
// import FnCounter from './components/FnCounter';
// import ListProducts from './components/ListProducts';
// import EditProduct from './components/EditProduct';
// import AddProduct from './components/AddProduct';
// import Login from './components/Login';
import 'bootstrap/dist/css/bootstrap.css'
import { Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'; //can use HashRouter/MemoryRouter as well.
import { isTemplateExpression } from 'typescript';
// import GadgetStore from './components/GadgetStore';
import Navigation from './components/Navigation';
import ProtectedRoute from './components/ProtectedRoute';
import {AppRoute, routes} from './routes/routes';


function App() {
  return (
//we can give <Ruuter basemane = "/App/"> and in package.json   // "homepage": "/App",
    <Router>
      <div className='container'>
        <Navigation/>

        {/* Routes(Views) to be rendered - can refactor this too*/}
        <main>
          <Suspense fallback = {"Loding..."}>
            <Routes>
              {/* <Route path='/' element={<Hello message='React'/>} />
              <Route path='/counter' element={<Counter value={10}/>} />
              <Route path='/fncounter' element={<FnCounter/>} />
              <Route path='/products' Component={ListProducts} />
              <Route path='/products/:id' Component={EditProduct} />
              <Route path='/products/add' Component={AddProduct} />
              <Route path='/gadgets' Component={GadgetStore} />
              <Route path='/login' Component={Login} /> */}

              {routes.map((item: AppRoute) => {
                if(item.isProtected){
                  return(

                      <Route path={item.path} element={<ProtectedRoute><item.component {...item.props} /></ProtectedRoute>} />

                  )
                }
                else{
                  return(
                    <Route key= {item.path} path={item.path} element={<item.component {...item.props} />} />
                  )
                }
                // return(
                //   <Route path={item.path} element={<item.component {...item.props} />} />
                // )
              })}
            </Routes>
            </Suspense>
        </main>
      </div>
    </Router>
  );
}

export default App;
