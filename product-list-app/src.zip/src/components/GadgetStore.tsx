//custom hook 
import { useAxiosFetchProducts } from '../hooks/useAxiosFetchProducts'
import { Product } from '../model/Product';
import {useDispatch, useSelector} from 'react-redux';
import { CartIem } from '../model/CartItem';
import {AppDispatch, AppState} from '../redux/store';
import { createAddToCartAction, createSetProductsAction } from '../redux/actionCreators';
import { useEffect } from 'react';
import { addItemToCart, fetchProductAsync } from '../redux/gadgetsReducer';

function GadgetStore(){
//Invoke the endpoint and fetch products,fetchproducts function has to be repeated
//Fetch Product sets the state and it is called inside a use effect to save the state. We need to design it to be reusable. 
//Design it to be a custom hook

    //const[products, setProducts] = useAxiosFetchProducts(); //products are fetched on component level
    const dispatch = useDispatch<any>();
    const products = useSelector ((state: AppState) => state.gadgets.products); //fetch products from store
    
    useEffect(() => {
       // dispatch({type: "SET_PRODUCTS"});
       //dispatch (createSetProductsAction());
       dispatch(fetchProductAsync());
    }, []);
    
    function addToCart(product: Product){
        //dispatch({type:"ADD_TO_CART", payload: new CartIem(product,1)});
       // dispatch(createAddToCartAction(new CartIem(product,1)));
       dispatch(addItemToCart(new CartIem(product, 1)));

    }


    function renderProducts() {

        const productsView =  products.map((item, index) => {
            return (
                <div className="col" key={index} >
                    <div className="card border-warning" >
                        <div className="card-body text-success">
                            <h5 className="card-title">{item.name}</h5>
                            <p className="card-text">{item.description}</p>
                            <p className="card-text text-primary">INR {item.price}</p>
                            <button className="btn btn-primary"onClick = {() => addToCart(item)}>Add To Cart</button>
                        </div>
                    </div>
    
                </div>
            );
        })
        return (
            <div className="row row-cols-1 row-cols-md-2 g-4">
                {productsView}
            </div>
        )
    }
    return(
        <div>
            <h4>Gadget Store</h4>
            {renderProducts()}
        </div>
    )
}
export default GadgetStore;

//Example of custom hook: Many technologies that we use there is a seperation between presentation and core, while using MVC design patter
//When we see the Login Component, JSX is the presentation logic and everything else is controller logic, and List Product has model
//React doesnt have segregation, but it you want the controller logic to be different from presentation layer and put in two different files -> we can do using hooks. 
//It can be in the same file as long as it is not over lapping/ its a choice for maintaning.