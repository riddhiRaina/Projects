// import {useEffect} from 'react'; 
// function ListProducts(){ 
 
// //useEffect takes a callback as an argument and list of dependencies 
// //useEffect => invoked only once on when mounted, pass an array of empty dependencies 
 
// //useEffect(() => {callback}, [dependencies]) 
 
// useEffect(() => {console.log("useEffect on mount");}, []); //will be called only once during the lifecycle of the component. Make API Call from React application. 
// //generate jsx 
// return( 
//     <div>
//     <h4>List Products</h4>
//     </div> 

// ) 

// } 
//export default ListProducts;

import {useEffect, useState} from 'react';
import axios from 'axios';
import {Product} from '../model/Product';
import './ListProducts.css';
import {useNavigate, Link} from 'react-router-dom';
import {useSelector} from 'react-redux'; //fetch data from store
import { useTitle } from '../hooks/useTitle';
import { AuthState } from '../redux/authReducer';
//have a link say add product -> should navigate to new page, capture all values and click on save -> make API call and push data to the backend. API Call should be POST. 

const base_url = process.env.REACT_APP_BASE_URL;

function ListProducts(){

    const navigate = useNavigate(); //Inside the function u cannot call the hook. The hook should be called inside the component function in the beginning.
    //useEffect(callback, [dependencies])
    //useEffect => invoked only once on when mounted, 
                            //  pass am array of empty denpendies
    useEffect(() => {
        console.log("useEffect on mount");
        fetchProducts();
    }, []);
    const [products, setProducts] = useState<Product []>([]);
    useTitle("Products");
    const auth = useSelector((state: any) => state.auth) as AuthState;


    function fetchProducts(){
        const accessToken  = auth.accessToken;
        const url = base_url + "/secure_products"; //login and return access token and pass it to the list product
        const headers = {"Authorization": `Bearer ${accessToken}`}
        axios
            .get<Array<Product>>(url, {headers})
            .then((response) => {
                   console.log("success", response.data); 
                   setProducts(response.data);

            }, (errorResponse) => {
                console.log("error", errorResponse); 
            });
    }

    // function deleteProduct(product: Product){ //Make API call and pass the ID
    //     const url = base_url + "/products/" + product.id;
    //     axios
    //          .delete(url)
    //          .then((response) => {

    //             fetchProducts(); //it will make an api call and call the updated products
    //             alert("Record Deleted");
    //          }, (errorResponse) => {
    //             alert("error - Could not delete Record");
    //          }) //need to ensure that the UI gets updated from the client side the record should be removed. 
    // }

    //Rewrite using asyn And await
    async function deleteProduct(product: Product){ //Make API call and pass the ID
        //const url = base_url + "/products/" + product.id;
        const url = base_url + "/secure_products/" + product.id; //for delete also we need secure products and pass token
        try
        {
            //promise fulfilled
            const response = await axios.delete(url); //response or the promise fulfilled, make it available for us
            fetchProducts(); //it will make an api call and call the updated products

            //Manually updating collection in the client side
            //instead of updating/refreshing from fetchProducts, try to delete from the UI -> Iterate over the list of products and change the state
            //create copy of products -> use spread operator //from the copy of products remove the product from array using splice and get the index of the item to splice
            const copy_of_products = [...products];
            const index = copy_of_products.findIndex(item => item.id == product.id);
            copy_of_products.splice(index,1);
            setProducts(copy_of_products);

            alert("Record Deleted");
        } catch (errorResponse) {
                //promise failed
                alert("Delete Unsuccessful");
            }
    }
    
    function editProduct(product: Product){
        navigate("/products/" + product.id);
    }

    function addProduct() {  
       navigate("/products/add");
      };  

    return (
        <div>
            <h4>List Products</h4>
            <Link to = "/products/add" className = "add-product-link" onClick={addProduct}>Add Product</Link>  
            <div style={{display: 'flex', flexFlow: 'row wrap', justifyContent: 'center'}}>
                {products.map((item: Product) => {
                    return (
                        <div className='product'  key={item.id} data-testid = "product" >
                            <p>Id: {item.id}</p>
                            <p>{item.name}</p>
                            <p>{item.price}</p>
                            <p>{item.description}</p>
                            <div>
                                <button className = 'btn btn-danger' 
                                                      onClick ={() => {deleteProduct(item)}}>Delete</button>&nbsp; {/*while calling handler event, we need to only provide the name of the method, so how to pass the argument? -> give arrow function, write a wrapper method when handler has to call an event*/} 
                                <button className = 'btn btn-danger'
                                                      onClick ={() => {editProduct(item)}}>Edit</button> {/*handle click event*/}
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    )
}

export default ListProducts;