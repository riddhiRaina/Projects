//Class Based component

import { Component, ReactNode} from "react";
import {withBorder} from '../hoc/withBorder';
import { withNavigate } from "../hoc/withNavigate";
type Counterprops={
    value:number
    title?:string
    navigate?: (value: string) => void //signature of navigate, takes string and return void
}
//class based component
class Counter extends Component<Counterprops>{ //class function, an instance is always created. To write instance we use this keyword
    // counter:number=0;
    state={
        counter:0,
        message: "hello" //dont put everything int state, use it judicially, only info that you want to display to the user should be displayed
    }
    constructor(props:Counterprops){
        super(props);
        this.state.counter=this.props.value;
 
    }
    // inc()
    // {
    //     console.log("inc invoked");
    //     // this.props.value++; //props is read only so we cannot change it
    //     this.counter++; //why is this coming undefined?
       
    // }
    inc =() =>{
        console.log("inc invoked");
        // this.props.value++; //props is read only so we cannot change it
        // this.state.counter++; //never modify state directly
        //this.setStete takes a slice of state and merges it with the existing state -> Its not the complete state. if we give message, only counter changes, message remains as it is.
        this.setState({
            counter:this.state.counter+1
        }); //setState is asynchronous and has to be re rendered properly
        //callback(invoked after the state is updated)
        console.log("counter",this.state.counter); //print value of counter
    }

    decr = () => {
        this.setState({
            counter: this.state.counter - 1
        })
    }

    navigateToHome = () => {
        //In class based components we cant use useNavigate using react router dom. Make use of higher order component to inject the navigation logic into the counter component
        if(this.props.navigate){
            this.props.navigate("/");
        }

    }

    render(){
        return(
            <div>
                <h4>Counter: {this.state.counter} {this.props.title}</h4>
                <p>This is a class based component</p>
                <div>
                    <button className="btn btn-success" onClick={this.inc}>Inc</button> &nbsp;
                    <button className="btn btn-danger" onClick={this.decr}>Decr</button> &nbsp;
                </div>
                <br/>
                <div>
                    <button className="btn btn-info" onClick = {this.navigateToHome}>Navigate To Home</button>
                </div>
            </div>
 
        )
    }

    componentDidMount(): void{
        console.log("[counter] mounted"); //API Calls
    }

    componentWillUnmount(): void{ //cleanup
        console.log("[counter] Unmounted");
    }

    componentDidUpdate(): void{ //which prop change or state change triggered the update can be done by comparing the values [Do update after the component has to be re-rendered]
        console.log("[counter] Updated");
    }
}
 
export default withNavigate(withBorder(Counter));