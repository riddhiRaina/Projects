// import { useState, useCallback, useMemo, useEffect } from "react";
// import axios from 'axios';
// import { useNavigate } from "react-router-dom";
import Alert from './Alert'
import {useLogin} from '../hooks/useLogin';
// import { useTitle } from '../hooks/useTitle'; //going to useLogin Hook


function Login(){

    const [userName, setUserName, password, setPassword, message, severity, SignIn, closeAlert, calculateValue] = useLogin();

    //controlled input using onchange - read the values in the input field/ make use of useRef
    //we can create multiple states
    // const [userName, setUserName] = useState("");
    // const [password, setPassword] = useState("");
    // const [message, setMessage] = useState("");
    // const [severity, setSeverity] = useState("");
    // const navigate = useNavigate();

    // //change title when login //will be invoked as soon as component is loaded
    // // useEffect(() => {

    // //     const originalTitle = document.title;
    // //     document.title = originalTitle + "-Login";

    // //     //when unmounted
    // //     return () => {
    // //         document.title = originalTitle;
    // //     }

    // // })
    // useTitle("Login");
    // //other option - create one object with different attributes and have only one state for example Products.[Edit Products]
    // async function SignIn() {
    //     if(userName && password){ //checks for null/undefined/empty string
    //         try{
    //             const url = "http://localhost:9001/login";
    //             const response = await axios.post(url, {name: userName, password});
    //             setMessage("");//setMessage("Validated"); 
    //             navigate("/products");
    //         } catch (error){
    //             setSeverity("warning");
    //             setMessage("Invalid credentials");
    //         }
    //     } 
    //     else{
    //         //setSeverity("info"); //there is no css class called alert error, we have alert danger => setSeverity("danger");
    //         setSeverity("error");
    //         setMessage("Provide the credentials");
    //     }
    // }
    // const closeAlert = useCallback(() => {
    //     setMessage("");
    // }, []) //callback for Memoization, the memory address shouldn't change.

    // // function closeAlert(){
    // //     setMessage("");
    // // }

    // //function is being called when password input is also changed. so, we useMemo to memoiz value only when username is entered
    // // const calculateValue = () => {
    // //     console.log("inCalculatedValue");
    // //     return userName + 1000;
    // // }

    // //Scenario: Function which has API Call and want values -> we dont want API call continuously we can make use of useMemo
    // //useMemo is only within the component, it cannot share with different states of different component. outside the component the memory is lost.
    // //Business usecase - dashboard has widgets, each widget is fetching info from different sources, calculating average/summation typically involves multiple datasources, it can involve filtering etc. If anything changes with the page like network change - which isnt need, unrelated widget value changes -> we can make use of useMemo 
    // //Page Relaods - it gets re generated, but for page mount and upload we will have memoized copy.
    // const calculateValue = useMemo(() => {
    //     console.log("inCalculatedValue");

    //     return userName + 1000;
    // },[userName]); //going to useLogin Hook

    return(
        <div>
            <h4>Login</h4>

            <p>Calculate Value : {calculateValue}</p>
            {/* {message ? <div className="alert alert-info">{message}</div> : null} */}

            {/* {message ? <Alert message={message} severity = {severity} onClose={closeAlert}/> : null} */}

            {message ? <Alert message={message} severity = {severity} onClose={closeAlert}/> : null}

            <div className="form-group">
                <label>UserName</label>
                <input className = "form-control" placeholder="UserName" value = {userName} onChange={e=>setUserName(e.target.value)}/>
            </div>

            <div>
                <label>Password</label>
                <input type = "password" className = "form-control" placeholder="******" value = {password} onChange={e=>setPassword(e.target.value)}/>
            </div>
            <br/>

            <div>
                <button className = 'btn btn-success' onClick={SignIn}>Login</button> 
            </div>

        </div>
    )
}

export default Login;