import { useSelector } from "react-redux";
import { Navigate } from "react-router-dom";
import { AuthState } from "../redux/authReducer";

//how to check if user is authenticated - acess the isAuthorized property
type ProtectedRouteProps = {
    children: any
}
function ProtectedRoute(props: ProtectedRouteProps){
    const auth = useSelector((state: any) => state.auth) as AuthState
    // return(
    //     <div>Protected Route</div>
    // )
    if(auth.isAuthenticated){
        return props.children;
    }
    else{
        return <Navigate to = "/login"/>
    }
}
export default ProtectedRoute;