import React from 'react';

//<Alert message = "Hello" severity="error" autoClose={true}/>
//Define Props

type AlertProps = {
    message: string //mandatory
    severity?: string; //optional, default value will be information
    autoClose?: boolean;
    onClose?: () => void; //this is a type annotation to denote a funtion that returns void
}
//React.memo - introduced in React 16.3 for optimization. It is also a higher order component
//Based on the Memoization pattern : cache the generated jsx - so that in subsequent rendering it will use the cache instead of re rendering again
//When state or props changes the component is re rendered

//store in global property 
const Alert = React.memo(function Alert(props: AlertProps){ 
    console.log("rendering alert");
    let severity = "info";

    if(props.severity){
        severity = props.severity;
        if(props.severity === "error"){
            severity = "danger"
        }
    }

    function close(){
        if(props.onClose){
            props.onClose();
        }
    }

// we can extend it to features using icon etc.
    return(
        <div className={`alert alert-${props.severity}`}>
            <p style={{width: "95%", display: "inline-block"}}>{props.message}</p>
            <button className={`btn btn-${severity}`} onClick={close}>
                <span>&times;</span>
            </button>
        </div>
    ) 
})
export default Alert;