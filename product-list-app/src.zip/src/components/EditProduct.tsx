//Functional Component
import { useState, useEffect, ChangeEvent } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Product } from '../model/Product';

const base_url = process.env.REACT_APP_BASE_URL;

function EditProduct(){

   // const location = useLocation();
    const params = useParams();
    const navigate = useNavigate();

    useEffect(() => {
        console.log("useEffect For Edit on Mount");
        fetchProduct();
    }, [])

    //const [product, setProduct] = useState<Product>(new Product()); //initially product value is undefined, when API call is complete then we will get the data. So never bind the data to null, initialize it.
    const [product, setProduct] = useState<Product>(new Product(0, "", 0, ""));
    async function fetchProduct(){
        try{
            const url = base_url + "/products/" + params.id;
            const response = await axios.get<Product>(url); //response should be of type product
            setProduct(response.data);
        }catch (error) {
            alert("Failed to fetch the product");
        }
    }

    function handleName(evt: ChangeEvent<HTMLInputElement>){
        const value = evt.target.value;
        //we have object/array - its immutable so we need to create a copy of that and make a change to the copy
        // const copy_of_product = {...product};
        // copy_of_product.name = value;
        // setProduct(copy_of_product);

        //simplification:
        setProduct({...product, name: value});
    }
    // function handlePrice(evt: ChangeEvent<HTMLInputElement>){
    //     const value = evt.target.value;
    //     //const copy_of_product = {...product};
    //     //copy_of_product.name = product.name;
    //     //setProduct(copy_of_product);
    //     setProduct({...product, price: Number(value)});
    // }
    // function handleDescription(evt: ChangeEvent<HTMLInputElement>){
    //     const value = evt.target.value;
    //     setProduct({...product, description: value});
    // }

    async function save() {
        //debugger;
        try{
            const url = base_url + "/products/" + product.id
            await axios.put(url, product);
            alert("Update Successful");
            navigate(-1);
        }catch(errorResponse){
            alert("Update Un-Successful");
        }
    }

    function cancel(){
        navigate("/products");
    }
    
    return(
        <div>
            {/*Designing to  capture the value*/}
            <h4>Edit Product: {params.id}</h4>
            <div className="form-group">
                <label>Name</label>
                <input className="form-control" value={product.name} onChange={handleName}/>
            </div>

            <div className="form-group">
                <label>Price</label>
                <input type = "number" className="form-control" value={product.price} onChange={(evt) => setProduct({...product, price: Number(evt.target.value)})}/>
            </div>

            <div className="form-group">
                <label>Description</label>
                <input className="form-control" value={product.description} onChange={e => setProduct({...product, description: e.target.value})}/>
            </div>

            <div>
                <button className="btn btn-primary" onClick = {save}>Save</button>
                <button className="btn btn-warning" onClick = {cancel}>Cancel</button>
            </div>

        </div>
    )
}

export default EditProduct;