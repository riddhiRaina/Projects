import { useState, useEffect, ChangeEvent } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Product } from '../model/Product';

const base_url = process.env.REACT_APP_BASE_URL;

function AddProduct(){
    
    const params = useParams();
    const navigate = useNavigate();

    useEffect(() => {
        console.log("useEffect For Edit on Mount");
        //fetchProduct();
    }, [])

    const [product, setProduct] = useState<Product>(new Product());
    // async function fetchProduct(){
    //     try{
    //         const url = base_url + "/products/" + params.id;
    //         const response = await axios.get<Product>(url); //response should be of type product
    //         setProduct(response.data);
    //     }catch (error) {
    //         alert("Failed to fetch the product");
    //     }
    //}

    function handleName(evt: ChangeEvent<HTMLInputElement>){
        const value = evt.target.value;
        setProduct({...product, name: value});
    }

    async function save() {
        //debugger;
        try{
            const url = base_url + "/products"  
            const response = await axios.get<Array<Product>>(url);  
            const products = response.data;  
           // const maxId = Math.max(...products.map((item) => item.id) ); 
            const maxId = Math.max(  
                ...products  
                  .map((item) => item.id ?? 0)  
              );   
            const nextId = maxId + 1;  
            const newProduct = { ...product, id: nextId }; 
            await axios.post(url, newProduct);
            alert("Update Successful");
            navigate("/products");
        }catch(errorResponse){
            alert("Update Un-Successful");
        }
    }

    function cancel(){
        navigate("/products");
    }
    
    return(
        <div>
            {/*Designing to  capture the value*/}
            <h4>Add Product:</h4>
            <div className="form-group">
                <label>Name</label>
                <input className="form-control" value={product.name} onChange={handleName}/>
            </div>

            <div className="form-group">
                <label>Price</label>
                <input type = "number" className="form-control" value={product.price} onChange={(evt) => setProduct({...product, price: Number(evt.target.value)})}/>
            </div>

            <div className="form-group">
                <label>Description</label>
                <input className="form-control" value={product.description} onChange={e => setProduct({...product, description: e.target.value})}/>
            </div>

            <div>
                <button className="btn btn-primary" onClick = {save}>Save</button>
                <button className="btn btn-warning" onClick = {cancel}>Cancel</button>
            </div>

        </div>
    )
}

export default AddProduct;