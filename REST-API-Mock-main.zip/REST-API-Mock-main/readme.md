# Node Express
#### See the package.json for the scrips to execute.

#### Run command  "npm install" to install dependencies 
#### Run command  "npm start" to start the service(starts on port 9000)
#### Run command  "npm start [portNo]" to start the service on specific port

