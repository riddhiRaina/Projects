﻿namespace ClassLibrary_project1
{
    public class TextManager
    {
        public static string GetDisplayMessage() => "Hello, World!";
    }
}