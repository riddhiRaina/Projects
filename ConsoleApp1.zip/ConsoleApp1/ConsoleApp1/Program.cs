﻿--Medicare APC
UPDATE[dbo].[LUT_PricerTypeVariable] SET[VariableDescr] = N'Used to adjust the base rate for each APC. The value is the same as that used for the hospital''s inpatient prospective payment calculations for the inpatient Fiscal Year (FY) of 2023.

Wage indices are effective October 01, 2022 (FY 2023) for inpatient reimbursement and effective January 01, 2023(CY 2023) for outpatient reimbursement. Updated wage indices can be found on the CMS web site(www.cms.gov).', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=104
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'1,600.00', [ModifiedTS] = '20230209 00:00:00.000' WHERE[LUTPTVID] = 105
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'0.9000', [ModifiedTS] = '20230209 00:00:00.000' WHERE[LUTPTVID] = 3578
UPDATE[dbo].[LUT_PricerTypeVariable] SET[SEQ] = N'', [VariableDescr] = N'The pro-rata reduction to be applied to the pass-through portion of the payment for drugs and biologicals with Payment Status Indicator G (Drug/Biological Pass-Through).

Note: These reductions have not been applied since January 2003, but may be applicable in the future.', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=110
UPDATE[dbo].[LUT_PricerTypeVariable] SET[SEQ] = N'', [ModifiedTS] = '20230209 00:00:00.000' WHERE[LUTPTVID] = 111
UPDATE[dbo].[LUT_PricerTypeVariable] SET[SEQ] = N'H.1', [ModifiedTS] = '20230209 00:00:00.000' WHERE[LUTPTVID] = 115
UPDATE[dbo].[LUT_PricerTypeVariable] SET[SEQ] = N'H.2', [ModifiedTS] = '20230209 00:00:00.000' WHERE[LUTPTVID] = 116
UPDATE[dbo].[LUT_PricerTypeVariable] SET[SEQ] = N'H.3', [VariableDescr] = N'The implantable device Ratio of Costs-to-Charges (RCCs). If available, this figure is used to calculate reimbursement for services assigned to Payment Status Indicator H (Pass-Through Device Categories). If not available, the outpatient RCC (SEQ H.1) is used.', [ModifiedTS] = '20230209 00:00:00.000' WHERE[LUTPTVID] = 3430
UPDATE[dbo].[LUT_PricerTypeVariable] SET[SEQ] = N'I.1', [VariableDescr] = N'Used to calculate line item cost outlier payments. The formula is as follows:

((Allocated Line Charges * H.1) - (I.3 * OPPS Line Payment)) *I.1', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=118
UPDATE[dbo].[LUT_PricerTypeVariable] SET[SEQ] = N'I.2', [DefaultValue]= N'8,625.00', [ModifiedTS]= '20230209 00:00:00.000' WHERE[LUTPTVID] = 119
UPDATE[dbo].[LUT_PricerTypeVariable] SET[SEQ] = N'I.3', [VariableDescr]= N'Factor used in the calculation of outlier payment. Refer to SEQ I.1  above.', [ModifiedTS]= '20230209 00:00:00.000' WHERE[LUTPTVID] = 120
UPDATE[dbo].[LUT_PricerTypeVariable] SET[SEQ] = N'J.1', [ModifiedTS]= '20230209 00:00:00.000' WHERE[LUTPTVID] = 117
UPDATE[dbo].[LUT_PricerTypeVariable] SET[SEQ] = N'J.2', [VariableDescr]= N'Factor used in the calculation of the hold harmless payment estimate for per claim reimbursement.

Effective January 01, 2013, hold harmless adjustments apply to cancer centers and children''s hospitals only.', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=123
UPDATE[dbo].[LUT_PricerTypeVariable] SET[SEQ] = N'J.3', [ModifiedTS]= '20230209 00:00:00.000' WHERE[LUTPTVID] = 124
UPDATE[dbo].[LUT_PricerTypeVariable] SET[SEQ] = N'J.4', [VariableDescr]= N'This factor was used to calculate transitional corridor payment estimates prior to January 01, 2004.

This factor is no longer used in the hold harmless payment calculation.', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=125
UPDATE[dbo].[LUT_PricerTypeVariable] SET[SEQ] = N'J.5', [ModifiedTS]= '20230209 00:00:00.000' WHERE[LUTPTVID] = 126
UPDATE[dbo].[LUT_PricerTypeVariable] SET[SEQ] = N'J.6', [VariableDescr]= N'This factor was used to calculate transitional corridor payment estimates prior to January 01, 2004.

This factor is no longer used in the hold harmless payment calculation.', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=127
UPDATE[dbo].[LUT_PricerTypeVariable] SET[SEQ] = N'J.7', [ModifiedTS]= '20230209 00:00:00.000' WHERE[LUTPTVID] = 128
UPDATE[dbo].[LUT_PricerTypeVariable] SET[SEQ] = N'J.8', [VariableDescr]= N'This factor was used to calculate transitional corridor payment estimates prior to January 01, 2004.

This factor is no longer used in the hold harmless payment calculation.', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=129
UPDATE[dbo].[LUT_PricerTypeVariable] SET[SEQ] = N'J.9', [VariableDescr]= N'This factor was used to calculate transitional corridor payment estimates prior to January 1, 2004.
This factor is no longer used in the hold harmless payment calculation.', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=130
UPDATE[dbo].[LUT_PricerTypeVariable] SET[SEQ] = N'J.10', [VariableDescr]= N'This factor was used to calculate transitional corridor payment estimates prior to January 01, 2004.

This factor is no longer used in the hold harmless payment calculation.', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=131
UPDATE[dbo].[LUT_PricerTypeVariable] SET[SEQ] = N'K.1', [VariableDescr]= N'Indicator used to request Medicare pricing for fee schedule items such as ambulance services, clinical laboratory services, Durable Medical Equipment, Prosthetics, Orthotics, and Supplies (DMEPOS), drugs and biologicals, and therapy services, which are not included in the OPPS (that is, selected services with a Payment Status Indicator of A, G, K, or Y).

Check this box to request fee schedule pricing. If you do not want fee schedule pricing, do not check this box, and do not complete the remaining fee schedule fields below (SEQ K.1 - SEQ K.3).', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=132
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'K.2', [DefaultValue]=N'fee2023', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=133
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'K.3', [VariableDescr]=N'The extended fee schedule table to be used for pricing.

Beginning January 01, 2017, the extended fee schedule table has been removed and has been combined with the fee schedule table (SEQ K.2).', [DefaultValue]=N'', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=134
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'K.4', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=3372
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'', [VariableDescr]=N'Invokes override functionality. The Edit Override functionality allows the user to turn particular Ambulatory Code Editor? (ACE) edits on or off.

Note: This is an optional field; please refer to the EASYGroup? Technical Reference Guide for further information.', [DefaultValue]=N'', [ModifiedTS]='20230209 00:00:00.000', [DisplayEndDate]='00010101' WHERE [LUTPTVID]=155
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'L.1', [VariableDescr]=N'Ambulance Carrier: Do not enter.

Note: The attached Medicare Fee Schedule Carrier Values RVW contains the carriers used for Ambulance Fee Schedule pricing and is for background information only. The Carrier Code for ambulance services is based on the zip code at point of pickup.', [DefaultValue]=N'', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=135
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'L.2', [VariableDescr]=N'Ambulance Payment Factor.

Note: Set to 1.0000 if co-payment is not desired.', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=136
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'L.3', [VariableDescr]=N'Ambulance services are paid 100% under the fee schedule methodology - 80% by Medicare and 20% by the patient.

For this field there are two options:
1. Enter 0.0000 if you do not want ambulance fee schedule pricing, or if you are not able to provide the zip code at point of pickup.
2. Enter 0.2000 to calculate pricing for ambulance services based on the full fee schedule rates.

Note: Set to 0.0000 if co-payment is not desired.', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=137
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'M.1', [DefaultValue]=N'', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=138
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'M.2', [VariableDescr]=N'DMEPOS Payment Factor

Note: Set to 1.0000 if co-payment is not desired.', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=139
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'M.3', [VariableDescr]=N'DMEPOS Co-Payment Factor

Note: Set to 0.0000 if co-payment is not desired.', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=140
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'N.1', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=141
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'N.2', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=142
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'N.3', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=143
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'O.1', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=144
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'O.2', [VariableDescr]=N'National Payment Factor

Note: Set to 1.0000 if co-payment is not desired.', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=145
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'O.3', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=146
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'P.1', [VariableDescr]=N'Physician (MD) Fee Schedule Carrier: Code identifying the carrier handling claims for this hospital that contain items payable under the Physician Fee Schedule.

Rehabilitation service fee schedule rates are based on the non-facility-based fees on Medicare''s Physician Fee Schedule.

Other services include screening mammography, and the Telehealth facility fee. Please refer to the attached Medicare Fee Schedule Carrier Values RVW of possible carriers for Medicare''s Physician Fee Schedule.', [DefaultValue]=N'', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=147
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'P.2', [VariableDescr]=N'Physician Payment Factor

Note: Set to 1.0000 if co-payment is not desired.', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=148
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'P.3', [VariableDescr]=N'Physician Co-Payment Factor

Note: Set to 0.0000 if co-payment is not desired.', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=149
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'Q.1', [DefaultValue]=N'', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=150
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'Q.2', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=151
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'Q.3', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=152
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'R.1', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=153
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'R.2', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=154
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'R.3', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=2757
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'R.4', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=3517
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'R.5', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=3518
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'S.1', [VariableDescr]=N'This factor is used to calculate the Medicare payment for certain diagnostic surgical services performed on the same day as colorectal cancer screening services.

Note: Set to 1.0000 if co-payment is not desired.', [DefaultValue]=N'0.8500', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=4247
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [SEQ]=N'S.2', [VariableDescr]=N'This factor is used to calculate the patient co-payment for certain diagnostic surgical services performed on the same day as colorectal cancer screening services.

Note: Set to 0.0000 if co-payment is not desired.', [DefaultValue]=N'0.1500', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=4248

--Medicare ESRD
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [DefaultValue]=N'0.51', [ModifiedTS]='20230209 00:00:00.000', [DisplayStartDate]='00010101' WHERE [LUTPTVID]=1309
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [DefaultValue]=N'0.55200', [ModifiedTS]='20230209 00:00:00.000', [DisplayStartDate]='00010101' WHERE [LUTPTVID]=1312
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [DefaultValue]=N'265.57', [ModifiedTS]='20230209 00:00:00.000', [DisplayStartDate]='00010101' WHERE [LUTPTVID]=1314
UPDATE [dbo].[LUT_PricerTypeVariable]
SET [VariableDescr]=N'This field is used for the quality-related payment reduction (based on a facility''s Total Performance Score) applied to the ESRD payment. Payment reductions can be up to 2%. Total Performance Scores have associated Quality Reduction Factors and Payment Reductions. Refer to Table 1, "Quality Reduction Factors for CY 2023," on page 13.

Note: For CY 2023, CMS paused the Quality Incentive Program. Therefore, all facilities have been set to 1.0000.', [ModifiedTS]='20230209 00:00:00.000', [DisplayStartDate]='00010101' WHERE [LUTPTVID]=1318
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'39.62', [ModifiedTS]= '20230209 00:00:00.000', [DisplayStartDate]= '00010101' WHERE[LUTPTVID] = 1338
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'25.59', [ModifiedTS]= '20230209 00:00:00.000', [DisplayStartDate]= '00010101' WHERE[LUTPTVID] = 1339
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'73.19', [ModifiedTS]= '20230209 00:00:00.000', [DisplayStartDate]= '00010101' WHERE[LUTPTVID] = 1340
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'23.29', [ModifiedTS]= '20230209 00:00:00.000', [DisplayStartDate]= '00010101' WHERE[LUTPTVID] = 1341
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'feesrd23', [ModifiedTS]= '20230209 00:00:00.000' WHERE[LUTPTVID] = 1391

--Medicare Physician
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'0.8500', [ModifiedTS]= '20230209 00:00:00.000' WHERE[LUTPTVID] = 4264
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'0.1500', [ModifiedTS]= '20230209 00:00:00.000' WHERE[LUTPTVID] = 4265
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'0.1000', [ModifiedTS]= '20230209 00:00:00.000' WHERE[LUTPTVID] = 3585
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'facphy23', [ModifiedTS]= '20230209 00:00:00.000' WHERE[LUTPTVID] = 3976
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'feephys23', [ModifiedTS]= '20230209 00:00:00.000' WHERE[LUTPTVID] = 2434


--ContractAPC
UPDATE[dbo].[LUT_PricerTypeVariable] SET[VariableDescr] = N'Used to adjust the base rate for each APC. The value is the same as that used for the hospital''s inpatient prospective payment calculations for the inpatient Fiscal Year (FY) of 2023.

Wage indices are effective October 01, 2022(FY 2023) for inpatient reimbursement and effective January 01, 2023(CY 2023) for outpatient reimbursement. Updated wage indices can be found on the Centers for Medicare & Medicaid Services(CMS) web site(www.cms.gov).', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=1496
UPDATE[dbo].[LUT_PricerTypeVariable] SET[VariableDescr] = N'Enter the desired base rate for APC Weight * Base Rate pricing. Leave the Base * Weight Pricing Flag and Base Rate field blank to price using APC rates.

Note: If an APC User Base Rate is set for an APC, it will be used in place of this Base Rate.

Valid entries for base rate are between $0.000 and $99, 999.999.', [DefaultValue]=N'85.585', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=1506
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'0.1000', [ModifiedTS] = '20230209 00:00:00.000' WHERE[LUTPTVID] = 3564
UPDATE[dbo].[LUT_PricerTypeVariable] SET[VariableDescr] = N'The fee schedule table to be used for pricing.

If utilizing the legacy format, the fee schedule file name must begin with fs.Do not check SEQ P.4.

If utilizing the new format, the fee schedule file name must begin fee and SEQ P.4 must be checked.', [DefaultValue]=N'fee2023', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=1550


--Medicare SNF
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'0.9000', [ModifiedTS] = '20230209 00:00:00.000' WHERE[LUTPTVID] = 3592
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'feesnf23', [ModifiedTS] = '20230209 00:00:00.000' WHERE[LUTPTVID] = 1035

--Wisconsin Medicaid APG
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'0.2610', [ModifiedTS] = '20230209 00:00:00.000' WHERE[LUTPTVID] = 2993
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'feewi23', [ModifiedTS] = '20230209 00:00:00.000' WHERE[LUTPTVID] = 3080

--Medicare FQHC
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'187.19', [ModifiedTS] = '20230209 00:00:00.000' WHERE[LUTPTVID] = 2981
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'feefq23', [ModifiedTS] = '20230209 00:00:00.000' WHERE[LUTPTVID] = 3956

--New York Medicaid APG(Enhanced)
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'1', [ModifiedTS] = '20230209 00:00:00.000' WHERE[LUTPTVID] = 4008
UPDATE[dbo].[LUT_PricerTypeVariable] SET[VariableDescr] = N'This age cutoff is used to determine whether a claim is eligible for any of the following special pediatric payment policies:

- Eligibility for the Vaccines for Children Program.
-Application of the pediatric psychotherapy adjustment.', [ModifiedTS]='20230209 00:00:00.000' WHERE [LUTPTVID]=4026

--Washington Medicaid APG
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'feewa23', [ModifiedTS] = '20230209 00:00:00.000' WHERE[LUTPTVID] = 3038

--Kansas Medicaid
UPDATE[dbo].[LUT_PricerTypeVariable] SET[VariableDescr] = N'The HealthCare Access Improvement Program (HCAIP) was terminated by Kansas Medicaid. This field is no longer applicable.', [ModifiedTS] = '20230209 00:00:00.000' WHERE[LUTPTVID] = 3314

--Kentucky Medicaid
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'38,788.00', [ModifiedTS] = '20230209 00:00:00.000' WHERE[LUTPTVID] = 2360

--Medicare ASC
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'feeasc23', [ModifiedTS] = '20230209 00:00:00.000' WHERE[LUTPTVID] = 1260

--Medicare Hospice
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'feehsp23', [ModifiedTS] = '20230209 00:00:00.000' WHERE[LUTPTVID] = 4203

--Medicare RHC
UPDATE[dbo].[LUT_PricerTypeVariable] SET[DefaultValue] = N'feerhc23', [ModifiedTS] = '20230209 00:00:00.000' WHERE[LUTPTVID] = 4305
