﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextExtraction
{
    public class Medicine
    {
        public string ? MedicineName { get; set; }
        public int PresRowId { get; set; }
        public int FreqRowId { get; set; }
        public int PodRowId { get; set; }
        public bool IsWithEmptyStomach { get; set; }
        public DateTime AddDate { get; set; }

        public DateTime ChangeDate { get; set; }

        public int AddBy { get; set; }

        public int ChangeBy { get; set; }

        public bool IsActive { get; set; }

        public bool Morning { get; set; }

        public bool Lunch { get; set; }

        public bool Night { get; set; }
    }
}
