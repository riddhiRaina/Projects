﻿using Microsoft.Azure.CognitiveServices.Vision.ComputerVision;
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using System;


namespace TextExtraction
{
    class Program
    {
        // put your Cognitive Service Key1 value
        static string Key = "b4ad017e05b241afad977bd2402ec067";
        // put your Cognitive Service URL
        static string url = "https://rid-textextraction.cognitiveservices.azure.com/";



        public static void Main(string[] args)
        {
            var client = new ComputerVisionClient(new ApiKeyServiceClientCredentials(Key));
            client.Endpoint = url;

            var drug = new List<string>()
                {"Pantodac", "Doxcef", "Sinarest", "Dolo","Supradyn", "Hydent.K Paste", "Neurotin 300mg","Tab.Zerodol SP", "Tab Rantec 150mg", "CAP SM FIBRO", "Acetylsalicylic acid 4g", "Phenacetin 0.8g", "codein sulfate 0.5g", "Mix and make capsules no. 20"};

            var myfile = File.OpenRead(@"C:\Users\rprasa58\Downloads\Prescription1.png");
          
   
            var result = client.RecognizePrintedTextInStreamAsync(false, myfile);
            result.Wait();

            var rst = result.Result;
            foreach (var r in rst.Regions)
            {
                foreach (var t in r.Lines)
                {
                    foreach (var w in t.Words)
                    {
                        var coordinates = w.BoundingBox.Split(',');
                        //result = from d in drug
                        // where w.Any(val => d.Description.Contains(val))
                        // select d;
                        var q = drug.Any(val => val == (w.Text));
                        if (q)
                        {
                            Console.WriteLine(w.Text);
                            var med = new Medicine();
                            med.MedicineName = w.Text;
                            med.AddDate = DateTime.Now;
                            med.ChangeDate = DateTime.Now;
                            med.Lunch = true;
                            med.Morning = true;
                            med.Night = false;
                            med.IsWithEmptyStomach = false;
                            CallWebAPIAsync(med).Wait();
                        }
                        // else
                        //{
                        //   Console.WriteLine("No match");

                        //Console.ReadLine();
                        //Console.WriteLine($"Found word {w.Text} at" +
                        //$" X {coordinates[0]} and Y {coordinates[1]}");
                    }
                }
            }
            static async Task CallWebAPIAsync(Medicine med)
            {
                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri("https://testapp1234sumanth.azurewebsites.net/");
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));


                    HttpResponseMessage response = await client.PostAsJsonAsync("api/Medicines", med);

                    if (response.IsSuccessStatusCode)
                    {
                        // Get the URI of the created resource.
                        //  UrireturnUrl = response.Headers.Location;
                        Console.WriteLine("ok");
                    }
                }
            }
        }
    }

    
}

