﻿namespace Case_Study.Models
{
    public class Project
    {

    }
}
