﻿using Microsoft.AspNetCore.Mvc;
using Case_Study.Models;

namespace Case_Study.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }

        public List<UserModel> Putvalue()
        {
            var user = new List<UserModel>
            {
                new UserModel{UserName = "test123", Password = "password123"}
            };

            return user;

        }

        [HttpPost]
        //public ActionResult verify(UserModel usp)
        //{
        //var u = Putvalue();
        //var ue = u.Where( u => u.UserName == usp.UserName );
        //var up = ue.Where(p => p.Password == usp.Password);
        //if(up.Count() == 1)
        //{
        //ViewBag.message("Login Success");
        //return View("Login");
        //}
        //else
        //{
        //ViewBag.message("Login Failed");
        //return View("Login");
        //}
        //}
        public IActionResult Login(UserModel model)
        {
            if(model.UserName == "test123" && model.Password == "password123")
            {
                return RedirectToAction("Project");
            }
            else
            {
                ViewData["Message"] = "Login Failed";
            }
            return View();
        }

        public IActionResult Project()
        {
            List<string> proj = new List<string>() { "EasyGroup", "Optum Exchange(OEPPS)", "Rate Manager", "Web.Strat", "Regulatory Portal", "Optum Wizard", "DMS", "APC Assistant", "EDC Analyzer" };
            return View(proj);

        }

    }
}
