using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Case_Study.Views.Login
{
    public class LoginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
