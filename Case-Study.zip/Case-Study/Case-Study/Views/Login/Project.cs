﻿namespace Case_Study.Views.Login
{
    public class Project
    {
    }
}
