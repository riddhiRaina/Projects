﻿// See https://aka.ms/new-console-template for more information
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Application_PPS
{
    public class Program
    {
        static void Main(String[] args)
        {
            _ = new List<EasyGroup>();
            List<string> ls1 = new(10)
            {
                "Allen", "Nicole", "Avi", "Monica", "Sid", "Prachi", "Advait", "Ellen", "Sam", "Naveen"
            };

            _ = new List<WebStrat>();
            List<string> ls2 = new(10)
            {
                "Nancy", "Steve", "Robin", "Max", "Lucas", "Dustin", "Eleven", "Jonathan", "Joyce", "Hopper"
            };

            _ = new List<NRM>();
            List<string> ls3 = new(10)
            {
                "Abijith", "Dheeraj", "Dinakar", "Bhrammam", "Mani", "Venky", "Lalith", "Prachi", "Krish", "Riddhi"
            };

            Console.WriteLine("Enter the project name\n");
            String? projectname = Console.ReadLine();
                if (projectname == "EasyGroup")
                {
                    Console.WriteLine("EasyGroup:\nTeam Members");
                    Console.WriteLine("******************************");
                    ls1.ForEach(Console.WriteLine);
                }

                else if (projectname == "WebStrat")
                {
                    Console.WriteLine("WebStrat:\nTeam Members");
                    Console.WriteLine("******************************");
                    ls2.ForEach(Console.WriteLine);
                }

                else if (projectname == "NRM")
                {
                    Console.WriteLine("NRM:\nTeam Members");
                    Console.WriteLine("******************************");
                    ls3.ForEach(Console.WriteLine);
                }
                else
                {
                    Console.WriteLine("Project Name Not Found");
                }
        }
    }
}